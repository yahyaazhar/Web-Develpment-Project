<!-- Test Code -->
<?php
	include_once("connection.php");
	
	//for entertaining search query
	if(isset($_POST['submit'])){
		$search = $_POST['search'];
		//$name = "Song of Horror";
		echo $search;
		
		//getting id of the game
		$gameQ = 'select * from games';
		$query = mysqli_query($link, $gameQ);
		
		$flag = 0;	// a chk for game existance
		while($row = mysqli_fetch_assoc($query)){
			$result = strcmp($search, $row['name']);
			if($result == 0){
				$flag = 1;
				
				$id = $row['id'];
				
				$q = 'select * from games where id='.$id;
				$query = mysqli_query($link, $q);
				
				break;
				
			}
		}
		
		if($flag == 0){
			echo "NO RESULT";
		}
		
		
	}
	else{
		$q = "select * from games";
		$query = mysqli_query($link, $q);
	}
	
	
	
	
	
?>

<html>
<head>

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>

<body class="container" style="background-color:black;">
</br></br>

<table class="table table-hover">
	
	<?php while($row = mysqli_fetch_assoc($query)) 
		  {
	?>		  
	<form class="form-group" method="get" action="" enctype="multipart/form-data" >
       <tr>
         <td><?php setImage($row['image']); ?></td>
         <td><?php echo "<span><a style='color:lightblue' href='viewPage.php?id=".$row['id']."'> ".$row['name']." </a></span>"; 
			?></td>
         <td style="color:white"><?php echo $row['genre'] ?></td>
         <td style="color:white"><?php echo $row['platform'] ?></td>
       </tr>
	</form>
	<?php }
	?>
	
</table>



	
</body>

</html>

<?php
	function setImage($img){
		$image = imagecreatefromstring($img);
		$image = imagescale($image, 130, 130);
		
		ob_start();
		imagejpeg($image);
		$content = ob_get_contents();
		ob_end_clean();
		echo '<img src="data:image/jpeg;base64,'.base64_encode($content).'"/>';
	}
?>