<?php
	 include_once("connection.php");
	 session_start();
	 
	 if(isset($_POST['submit']))  {
		 
		 $name = $_POST['myname'];
		// $image = $_POST['myimage'];
		 $genre = $_POST['mygenre'];
		 $platform = $_POST['myplatform'];
		 $company = $_POST['mycompany'];
		 $desc = $_POST['mydesc'];
		 $youtube = $_POST['ytlink'];
		 $steam = $_POST['stlink'];
		 $otherlink = $_POST['otherlink'];
		 $username = $_SESSION['username'];
		 
		 /*image processing*/
		$imageName = mysqli_real_escape_string($link, $_FILES['myimage']['name']);
		$imageData = mysqli_real_escape_string($link, file_get_contents($_FILES['myimage']['tmp_name']));
		$imageType = mysqli_real_escape_string($link, $_FILES['myimage']['type']);
		
		 
	 
		$q = "insert into games (image, name, genre, platform, companyName, description, youtube, steam, link, username) value ('$imageData','$name', '$genre', 
												'$platform', '$company', '$desc', '$youtube', '$steam', '$otherlink', '$username')";
		
		//$rs = mysqli_query($link, $q);
		$rs = mysqli_query($link, $q);
	 
		if($rs){
			echo"record has be saved";
		}
		else{
			echo"Fail to save";
		    die(mysqli_error($link));
		}  
	 }
	 else {
		 
	 }

?>	

<html>
<head>

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>

<body class="container">
<br/><br/>
<form class="form-group" method="post" action="" enctype="multipart/form-data" >
	
	<label for="img">Select Image: </label>
	<input type="file" id="myimage" name="myimage" accept="image/*" required/>
	<br/>
	<label>Name:</label>
	<input type="text" class="form-control" name="myname" id="myname" placeholder="Enter Game Title" required/>
	<br/>
	<label>Genre:</label>
	<select class="form-control" name="mygenre" id="mygenre"> 
		<option value="action">Action </option>
		<option value="adventure">Adventure </option>
		<option value="sports">Sports </option>
		<option value="shooters">Shooting </option>
		<option value="rpg">RPG </option>
		<option value="puzzlparty">Puzzle or Party </option>
	</select>
	<br/>
	<label>Platfom:</label>
	<input type="text" class="form-control" name="myplatform" id="myplatform" placeholder="Enter Game Platfom" required/>
	<br/>
	<label>Company Name:</label>
	<input type="text" class="form-control" name="mycompany" id="mycompany" placeholder="Enter Game Company Name" required/>
	<br/>
	<label>Destricption:</label>
	<input type="text" class="form-control" name="mydesc" id="mydesc" placeholder="Enter Game Desc" />
	<br/>
	<label>Trailer Link:</label>
	<input type="text" class="form-control" name="ytlink" id="ytlink" placeholder="Enter Video Link" />
	<br/>
	<label>Steam Link:</label>
	<input type="text" class="form-control" name="stlink" id="stlink" placeholder="Enter Steam Link" />
	<br/>
	<label>Other Link:</label>
	<input type="text" class="form-control" name="otherlink" id="otherlink" placeholder="Enter Any Other Download Link" />
	<br/>
	
	<button type="submit" name="submit" class="btn btn-primary">Insert Value</button>

</form>

</body>


</html>