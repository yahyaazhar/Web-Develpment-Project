<?php
    include_once("connection.php");

?>


<html>
<head>
<title>Web Project</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery-3.1.1.min.js"></script>
        <!-- Bootstrap js link -->
        <script src="js/bootstrap.min.js"></script>

</head>

<body class="container" style="background-color: black;">
<div class="navbar navbar-dark">
            <div class="container">
            <div class="navbar-header ">
                <img src="./img/GIP_logo.jpg" width="60px" height="60px" />
            </div>
            <ul class="nav navbar-nav navbar-left">
            <li><a href="#">Home</a></li>
            <li class="dropdown"><a  href="#" class="dropdown-toggle" data-toggle="dropdown">About<i class="caret"></i></a>
            <ul class="dropdown-menu">
            <li><a href="#">video</a></li>
            <li><a href="#">gallery</a></li>
            <li><a href="#">Music</a></li>
            </ul>
            </li>
            <li><a href="#">Contact Us</a></li>
            <li><button type="submit" class="btn btn-primary" style="margin-top: 14px; margin-left: 40px;"><span class="glyphicon glyphicon-search"></span></button></li>
            <li><div class="search-container" style="margin-top: 15px; margin-left: 10px;"><input type="text" placeholder="Search" name="search" style="width: 200%;" /></div></li>
            
            </ul>
            <ul class="nav navbar-nav navbar-right">
            <li><a data-toggle="modal" data-target="#myModal" class="btn btn-info" style="margin-top: 5px;">Signin</a></li>
            </ul>
            
            </div>
            
            </div>
        </div>

        <div class="modal fade" id="myModal" role="dialog" >
            <div class="modal-dialog modal-md">
                <div class="modal-content">

                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times</button>
                        <h4 class="modal-title">Signin</h4>

                    </div>

                    <div class="modal-body">
                        <form class="form-group">
                            <label>User Name:</label>
                            <input type="text" class="form-control" placeholder="Enter your name" />
                            <label>Password: </label>
                            <input type="password" class="form-control" placeholder="Enter your password" />
                        </form>

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn-primary" style="float: left;">Signup</button>
                        <button type="button" class="btn-default" style="float: right;">Signin</button>
                    </div>
                </div>

            </div>
        </div>
        <br /> 

        <?php 
            $r="select * from view_all";
            $rs=mysqli_query($link,$r);
        ?>
            <table class="table table-hover">
        <thead>
            <tr>
                <th style="color: white;"><b>Name</b></th>
                <th style="color: white;"><b>Image</b></th>
                <th style="color: white;"><b>Genre</b></th>
                <th style="color: white;"><b>Platform</b></th>
            </tr>
        </thead>
        <?php
            $num=0;
            while($rows=mysqli_fetch_assoc($rs))
            {
                if($num>9){
        ?>
        <thead>
            <tr>
                <th style="color: white; vertical-align:middle;"><?php echo $rows['name']; ?></th>
                <th><?php echo '<img src="data:image/jpeg;base64,'.base64_encode($rows['image']).'" width="40%" height="30%" class="img-rounded" />' ?></th>
                <th style="color:white; vertical-align:middle;"><?php echo $rows['genre']; ?></th>
                <th style="color:white; vertical-align:middle;"><?php echo $rows['Platform']; ?></th>
            </tr>
        </thead>
        <?php
                }
            $num++;
            
            }
        ?>
    </table>

    <nav style="text-align:center;">
    <ul class="pagination">
            <li>
                <a href="viewall.php" aria-label="previous">
                    <span aria-hidden="true">&laquo;</span>
                    <span class="sr-only ">previous</span>
                </a>
            </li>
            <li><a href="viewall.php">1</a></li>
            <li class="active"><a href="#">2</a></li>

            <li class="disabled">
                <a href="viewall1.php" aria-label="next">
                    <span aria-hidden="true">&raquo;</span>
                    <span class="sr-only">next</span>
                </a>
            </li>

    </ul>
    </nav>

    <div class="container">
                <div class="col-md-12">
                    <div class="col-md-2">
                        <img src="./img/GIP_logo.jpg" width="100px" height="100px" style="margin-top: 25px;" />
                    </div>
                    <br /><br />
                    <div class="col-md-6">
                        <a href="#">About</a> &nbsp&nbsp&nbsp&nbsp <a href="#">Blog</a>
                        &nbsp&nbsp&nbsp&nbsp <a href="#">News</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Help Center</a>
                        &nbsp&nbsp&nbsp&nbsp <a href="#">Sitemap</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Terms of Services & honor code</a>
                        &nbsp&nbsp&nbsp&nbsp <a href="#">Privacy Policy</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Acceptibility policy</a>
                        <br /><br />
                        <p>@Copyrights <i class="fa fa-copyright" aria-hidden="true"></i> 2020 Game Info Portal inc. All rightes reserved except where noted</p>
                    </div>
                    <br />
                    <div class="col-md-4">
                        <a href="www.facebook.com"><img src="./img/fb_icon.png" /></a>&nbsp&nbsp
                        <a href="www.youtube.com"><img src="./img/youtube-logo.png" /></a>&nbsp&nbsp
                        <a href="www.twitter.com"><img src="./img/twiiter-icon.png" /></a>&nbsp&nbsp
                        <a href="www.googleplus.com"><img src="./img/g+.png" /></a>&nbsp&nbsp
                        <a href="www.linkedin.com"><img src="./img/linkedin-icon.png" /></a>
                    </div>
                </div>
            </div>




</body>


<footer>
</footer>
</html>