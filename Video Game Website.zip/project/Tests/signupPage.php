<!-- For Singup Page for users -->
<?php
	include_once("connection.php");
	session_start();
	
	if(isset($_POST['submit']))  {
		 
		$name = $_POST['name'];
		// $image = $_POST['myimage'];
		$username = $_POST['username'];
		$email = $_POST['email'];
		$password = $_POST['password'];	
		 
		/* First we will check username/pass/email valid */
		$selectQ = "select * from usertable";
		$userQuery = mysqli_query($link, $selectQ);
			
		$match;
		while($row = mysqli_fetch_assoc($userQuery)){
			$match = strcmp($username, $row['username']);
			if($match == 0){
				//username is already taken;
				echo '<script> alert("username is already taken!"); </script>';
			}
		} 
		 
		 
		 /*image processing*/
		$imageName = mysqli_real_escape_string($link, $_FILES['image']['name']);
		$imageData = mysqli_real_escape_string($link, file_get_contents($_FILES['image']['tmp_name']));
		$imageType = mysqli_real_escape_string($link, $_FILES['image']['type']);
		
		 
	 
		$q = "insert into usertable (image, name, email, username, password) value ('$imageData','$name', '$email', '$username', '$password')";
		
		//$rs = mysqli_query($link, $q);
		$rs = mysqli_query($link, $q);
	 
		if($rs){
			echo"record has be saved";
			//sign the user and redirect to main page
			
			$_SESSION['username'] = $username;
			$_SESSION['admin'] = 0;			//as this page is only responsible for user signup/
			
			header('Location: main.php');
		
		}
		else{
			echo"Fail to save";
		    die(mysqli_error($link));
		}  
	 }
	 else {
		 
	 }
	
	function checkValid($username, $password, $email){
		
		
	}
	
	
?>

<?php
	
?>

<html>
<head>

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>

<body class="container">
</br></br>

<form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
							
							<label for="img">Select Profile Pic: </label>
							<input type="file" id="myimage" name="image" accept="image/*" required/>
							<label>Name:</label>
                            <input type="text" class="form-control" placeholder="Name" name="name" />
							<label>email:</label>
                            <input type="emial" class="form-control" placeholder="email" name="email" />		
                            <label>User Name:</label>
                            <input type="text" class="form-control" placeholder="Enter Username" name="username" />
                            <label>Password: </label>
                            <input type="password" class="form-control" placeholder="Enter Password" name="password" />
                       

                    </div>

                    <div class="modal-footer">
                        <button type="submit" value="submit" name="submit" class="btn-primary" style="float: left;">Signup</button>
                    </div>
					
</form>


	
</body>

</html>
