<!-- contact us -->
<?php
	 include_once("connection.php");
	 session_start();
	 
	 
	 if(isset($_POST['submit']))  {
		 
		 
		 $name = $_POST['myname'];
		// $image = $_POST['myimage'];
		 $email = $_POST['myemail'];
		 $msg = $_POST['mymsg'];
		
		$q = "insert into contact(name, email, message) value ('$name', '$email', '$msg')";
		
		//$rs = mysqli_query($link, $q);
		$rs = mysqli_query($link, $q);
	 
		if($rs){
			echo "Message Sent";
			header('Location: contactUs.php');
		}
		else{
			echo"Fail to save";
		    die(mysqli_error($link));
		}  
	 }
	 else {
		 
	 }

?>	

<html>
<head>
<meta charset="utf-8">

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script >
		function check(){
			alert("WHY");
		}
</script>

</head>

<body class="container">
<br/><br/>
<form class="form-group" method="post" action="" enctype="multipart/form-data" >
	
	<label>Name:</label>
	<input type="text" class="form-control" name="myname" id="myname" placeholder="username">
	<br/>
	<label>Email:</label>
	<input type="text" class="form-control" name="myemail" id="myemial" placeholder="email" required/>
	<br/>
	<label>Message:</label>
	<input type="textbox" class="form-control" name="mymsg" id="mymsg" placeholder="Your Message" required/>
	<br/>
	
	<br/>
	
	<button type="submit" name="submit" class="btn btn-primary">Send</button>
	<!--<input class="btn btn-primary" type="button" value="Setter" onclick="setter()"> -->

</form>

</body>




</html>

