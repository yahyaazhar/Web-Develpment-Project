<!-- For Singin Page -->
<?php
	include_once("connection.php");
	session_start();
?>

<html>
<head>

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>

<body class="container">
</br></br>

<form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        
                            <label>User Name:</label>
                            <input type="text" class="form-control" placeholder="Enter Username" name="username" />
                            <label>Password: </label>
                            <input type="password" class="form-control" placeholder="Enter Password" name="password" />
                       

                    </div>

                    <div class="modal-footer">
                
                        <button type="submit" value="submit" name="submit" style="margin-right:50%">Signin</button>
                    </div>
					
</form>

<a href="signupPage.php"> <button class="" style="margin-left:50%">Signup </a></button>


	
</body>

</html>

<?php
if(isset($_POST['submit'])){
		//first chk wheather the user exist in database or not
		//if yes then save the it in session variable
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		
		
		/*	Query for finding user in admintable	*/
		$q = "select * from admintable";
		$query = mysqli_query($link, $q);
											 //admin Status	
		findUser($query, $username, $password, 1);
		
		/*	Query for finding user in usertable	*/
		$q = "select * from usertable";
		$query = mysqli_query($link, $q);
		
		findUser($query, $username, $password, 0);
		
	}
	else{
		//nothing
	}

?>

<?php
	function findUser($query, $username, $password, $admin_status){
		$flag = 0;
		while($row = mysqli_fetch_assoc($query)){
			$username_chk = strcmp($username, $row['username']);
			if($username_chk == 0){
				//found!
				$flag = 1;
				echo "user found\n";
				if($password == $row['password']){
					echo "YOu are LOged IN\n";
					$_SESSION['username'] = $username;
					$_SESSION['admin'] = $admin_status;
					//redirect the user to main page
					header('Location: main.php');
					return;
				}else{
					echo "Password did not match\n";
				}
				
				break;
			}
		}
		
		if($flag == 0){
			echo "user not found!";
		}
	}
?>