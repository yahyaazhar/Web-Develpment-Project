<!-- For TESTING ONLY -->
<?php
	include_once("connection.php");
	if(isset($_GET['id'])){
		$selected_ID = $_GET['id'];
		$name = 'Song of Horror';
		$q = "select * from games where id=".$selected_ID;
		$query = mysqli_query($link, $q);
		$row = mysqli_fetch_assoc($query);
		
	}
	else{
		echo '<script> alert("Game ID not found!") </script>';
	}
	
	
?>

<html>
<head>

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>

<body class="container">
</br></br>


<?php setImage($row['image']); ?>
<br/>
<?php echo $row['name']; ?>
<br/>
<?php echo $row['genre']; ?>
<br/>
<?php echo $row['platform']; ?>
<br/>
<?php echo $row['companyName']; ?>
<br/>
<?php echo $row['description']; ?>
<br/>
<a href="<?php echo $row['youtube']; ?>"><?php echo $row['name'] ?></a>
<br/>
<a href="<?php echo $row['steam']; ?>"><?php echo $row['steam']; ?></a>
<br/>
<a href="<?php echo $row['link']; ?>"><?php echo $row['link']; ?></a>
<br/>





	
</body>

</html>

<?php
	function setImage($img){
		$image = imagecreatefromstring($img);
		$image = imagescale($image, 512, 512);
		
		ob_start();
		imagejpeg($image);
		$content = ob_get_contents();
		ob_end_clean();
		echo '<img src="data:image/jpeg;base64,'.base64_encode($content).'"/>';
	}
?>