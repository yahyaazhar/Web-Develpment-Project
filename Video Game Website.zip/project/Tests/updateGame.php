<!-- updating game -->
<?php
	 echo "UPDAING THE GAME!\n";
	 include_once("connection.php");
	 
	 $selected_ID; 
	// $_REQUEST
	 if(isset($_GET['id'])){
		 $selected_ID = $_GET['id'];
		 $q = "select * from games where id=".$selected_ID;
		 $query = mysqli_query($link, $q);
		 $row = mysqli_fetch_assoc($query);
		 
	 }else{
		 echo "NO  GET";
	 }
	 
	 
	 if(isset($_POST['submit']))  {
		 
		 
		 $name = $_POST['myname'];
		// $image = $_POST['myimage'];
		 $genre = $_POST['mygenre'];
		 $platform = $_POST['myplatform'];
		 $company = $_POST['mycompany'];
		 $desc = $_POST['mydesc'];
		 $youtube = $_POST['ytlink'];
		 $steam = $_POST['stlink'];
		 $otherlink = $_POST['otherlink'];
		 
		 /*image processing*/
		$imageName = mysqli_real_escape_string($link, $_FILES['myimage']['name']);
		$imageData = mysqli_real_escape_string($link, file_get_contents($_FILES['myimage']['tmp_name']));
		$imageType = mysqli_real_escape_string($link, $_FILES['myimage']['type']);
		 
	 
		$q = "UPDATE games SET name= '$name', genre= '$genre', platform = '$platform', description='$desc', 
				youtube='$youtube', steam='$steam', link='$otherlink'
				WHERE id=".$selected_ID;
		
		//$rs = mysqli_query($link, $q);
		$rs = mysqli_query($link, $q);
	 
		if($rs){
			echo"record Updated";
			header('Location: edit_games.php');
		}
		else{
			echo"Fail to save";
		    die(mysqli_error($link));
		}  
	 }
	 else {
		 
	 }

?>	

<html>
<head>
<meta charset="utf-8">

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

<script >
		function check(){
			alert("WHY");
		}
</script>

</head>

<body class="container">
<br/><br/>
<form class="form-group" method="post" action="" enctype="multipart/form-data" >
	
	<label for="img">Select Image: </label>
	<input type="file" id="myimage" name="myimage" accept="image/*" required/>
	<br/>
	<label>Name:</label>
	<input type="text" class="form-control" name="myname" id="myname" placeholder="Enter Game Title" required/>
	<br/>
	<label>Genre:</label>
	<select class="form-control" name="mygenre" id="mygenre"> 
		<option value="action">Action </option>
		<option value="adventure">Adventure </option>
		<option value="sports">Sports </option>
		<option value="shooters">Shooting </option>
		<option value="rpg">RPG </option>
		<option value="puzzlparty">Puzzle or Party </option>
	</select>
	<br/>
	<label>Platfom:</label>
	<input type="text" class="form-control" name="myplatform" id="myplatform" placeholder="Enter Game Platfom" required/>
	<br/>
	<label>Company Name:</label>
	<input type="text" class="form-control" name="mycompany" id="mycompany" placeholder="Enter Game Company Name" required/>
	<br/>
	<label>Destricption:</label>
	<input type="text" class="form-control" name="mydesc" id="mydesc" placeholder="Enter Game Desc" />
	<br/>
	<label>Trailer Link:</label>
	<input type="text" class="form-control" name="ytlink" id="ytlink" placeholder="Enter Video Link" />
	<br/>
	<label>Steam Link:</label>
	<input type="text" class="form-control" name="stlink" id="stlink" placeholder="Enter Steam Link" />
	<br/>
	<label>Other Link:</label>
	<input type="text" class="form-control" name="otherlink" id="otherlink" placeholder="Enter Any Other Download Link" />
	<br/>
	
	<button type="submit" name="submit" class="btn btn-primary">Update Values</button>
	<!--<input class="btn btn-primary" type="button" value="Setter" onclick="setter()"> -->

</form>

<script type="text/javascript">

		var name = document.getElementById("myname").value.trim();
		var name = "<?php echo $row['name']; ?>"; 
		
		document.getElementById('myname').value = "<?php echo $row['name']; ?>";
		document.getElementById('myplatform').value = "<?php echo $row['platform']; ?>";
		document.getElementById('mygenre').value = "<?php echo $row['genre']; ?>";
		document.getElementById('mycompany').value = "<?php echo $row['companyName']; ?>";
		document.getElementById('mydesc').value = "<?php echo $row['description']; ?>";
		document.getElementById('ytlink').value = "<?php echo $row['youtube']; ?>";
		document.getElementById('stlink').value = "<?php echo $row['steam']; ?>";
		document.getElementById('otherlink').value = "<?php echo $row['link']; ?>";
		
	
</script>



</body>

<?php 
	function testFun(){ 
		echo "TEST!";
		echo '<script type="text/javascript">check();</script>';
	}
?>



</html>

