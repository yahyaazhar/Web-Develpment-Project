<?php
	 include_once("connection.php");
	 session_start();
	 
	 if(isset($_POST['submit']))  {
		 $name = $_POST['myname'];
		// $image = $_POST['myimage'];
		 $genre = $_POST['mygenre'];
		 $platform = $_POST['myplatform'];
		 $company = $_POST['mycompany'];
		 $desc = $_POST['mydesc'];
		 $youtube = $_POST['ytlink'];
		 $steam = $_POST['stlink'];
		 $otherlink = $_POST['otherlink'];
		 $username = $_SESSION['username'];
		 
		 /*image processing*/
		$imageName = mysqli_real_escape_string($link, $_FILES['myimage']['name']);
		$imageData = mysqli_real_escape_string($link, file_get_contents($_FILES['myimage']['tmp_name']));
		$imageType = mysqli_real_escape_string($link, $_FILES['myimage']['type']);
		
		 
	 
		$q = "insert into games (image, name, genre, platform, companyName, description, youtube, steam, link, username) value ('$imageData','$name', '$genre', 
												'$platform', '$company', '$desc', '$youtube', '$steam', '$otherlink', '$username')";
		
		//$rs = mysqli_query($link, $q);
		$rs = mysqli_query($link, $q);
	 
		if($rs){
			echo"record has be saved";
		}
		else{
			echo"Fail to save";
		    die(mysqli_error($link));
		}  
	 }
	 else {
		 
	 }

?>	


<html>
    <head>
        <title>New Entry</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery-3.1.1.min.js"></script>
        <!-- Bootstrap js link -->
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body style="background-color:black;">

        <div class="navbar navbar-dark">
            <div class="container">
            <div class="navbar-header ">
                <img src="./img/GIP_logo.jpg" width="60px" height="60px" />
            </div>
            <ul class="nav navbar-nav navbar-left">
            <li><a href="main.php">Home</a></li>
            <li class="dropdown"><a  href="#" class="dropdown-toggle" data-toggle="dropdown">About<i class="caret"></i></a>
            <ul class="dropdown-menu">
            <li><a href="#">video</a></li>
            <li><a href="#">gallery</a></li>
            <li><a href="#">Music</a></li>
            </ul>
            </li>
            <li><a href="contactUsPage.php">Contact Us</a></li>
            
			<!-- For Searching -->
		
		<form action="view_all.php" method="POST" enctype="multipart/form-data">
            <li>
			<div class="search-container" style="margin-top: 15px; margin-left: 10px;">
			<input type="text" placeholder="Search" id="search" name="search" style="width: 200%;" />
			</div>
			</li>
			<li><button type="submit" value="submit" name="submit" class="btn btn-primary" style="margin-top: 14px; margin-left: 180px;">
			<span class="glyphicon glyphicon-search">
			</span></button>
			</li>
		</form>
		
		<!-- -->
			
            </ul>
            <!--- Changing Sign In Depend Log in Status -->
            
			<?php 
			if(!isset($_SESSION['username'])) { ?>
				<ul class="nav navbar-nav navbar-right">
				<li><a href="signinPage.php" class="btn btn-info" style="margin-top: 5px;">Signin</a></li>
				</ul>
            <?php } 
			
			else if(isset($_SESSION['username']) && $_SESSION['admin'] == 1){ ?>
				<ul class="nav navbar-nav navbar-right">
				<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle btn-primary" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Dropdown
				</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
					<a class="dropdown-item" href="newentry.php">Add Games</a>
					<a class="dropdown-item" href="edit_games.php">Edit Games</a>
					<a class="dropdown-item" href="signoutPage.php">Signout</a>
					
				</div>
				</li>
				</ul>
			<?php } 
			else if(isset($_SESSION['username']) && $_SESSION['admin'] == 0){ ?>
				<ul class="nav navbar-nav navbar-right">
				<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle btn-primary" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					ForUser
				</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
					<a class="dropdown-item" href="insert.php">Upload Game</a>
					<a class="dropdown-item" href="userProfile.php">My Profile</a>
					<a class="dropdown-item" href="signoutPage.php">Signout</a>
					
				</div>
				</li>
				</ul>
			<?php } ?>
            
            </div>
            
            </div>
        </div>

        <br /><br /><br /><br />

        <div class="container" style="background-color: darkgray; border-radius: 25px;">
            <form class="form-group" method="post" action="" enctype="multipart/form-data" >
                <br />
                <label for="img">Select Image: </label>
                <input class="form-control" type="file" id="myimage" name="myimage" accept="image/*" style="background-color: lightgray;" required/>
                <label>Name:</label>
                <input class="form-control" type="text" placeholder="Enter game title" name="myname" id="myname" style="background-color: lightgray;" />
                <label>Genre:</label>
                <br />
                <select class="form-control" name="mygenre" id="mygenre" style="width: 100%; height: 6%; border-radius: 5px; background-color: lightgray;">
                    <option selected disabled>Choose the Genre</option>
                    <option value="action">Action </option>
					<option value="adventure">Adventure </option>
					<option value="sports">Sports </option>
					<option value="shooters">Shooting </option>
					<option value="rpg">RPG </option>
					<option value="puzzlparty">Puzzle or Party </option>
                </select>
                <br />

                <label>Platform:</label>
                <input class="form-control" type="text" placeholder="Enter Game Platform" name="myplatform" id="myplatform" style="background-color: lightgray;" />
                <label>Company Name:</label>
                <input class="form-control" type="text" placeholder="Enter Game Company Name" name="mycompany" id="mycompany" style="background-color: lightgray;" />
                <label>Description:</label>
                <input class="form-control" type="text" placeholder="Enter Game Description" name="mydesc" id="mydesc" style="background-color: lightgray;" />
                <label>Trailer link:</label>
                <input class="form-control" type="text" placeholder="Enter Trailer link" name="ytlink" id="ytlink" style="background-color: lightgray;" />
                <label>Steam link:</label>
                <input class="form-control" type="text" placeholder="Enter Steam Link" name="stlink" id="stlink" style="background-color: lightgray;" />
                <label>Other link:</label>
                <input class="form-control" type="text" placeholder="Enter any other sourse link" name="otherlink" id="otherlink" style="background-color: lightgray;" />
                <br />
                <button type="submit" name="submit" class="btn btn-info" style="float: left;">Register Entry</button>
                <br /><br />
            </form>
        </div>
        <br />
        <div class="container" >
            <div class="col-md-12">
                <div class="col-md-2">
                    <img src="./img/GIP_logo.jpg" width="100px" height="100px" style="margin-top: 25px;" />
                </div>
                <br /><br />
                <div class="col-md-6">
                    <a href="#">About</a> &nbsp&nbsp&nbsp&nbsp <a href="#">Blog</a>
                    &nbsp&nbsp&nbsp&nbsp <a href="#">News</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Help Center</a>
                    &nbsp&nbsp&nbsp&nbsp <a href="#">Sitemap</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Terms of Services & honor code</a>
                    &nbsp&nbsp&nbsp&nbsp <a href="#">Privacy Policy</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Acceptibility policy</a>
                    <br /><br />
                    <p>@Copyrights <i class="fa fa-copyright" aria-hidden="true"></i> 2020 Game Info Portal inc. All rightes reserved except where noted</p>
                </div>
                <br />
                <div class="col-md-4">
                    <a href="www.facebook.com"><img src="./img/fb_icon.png" /></a>&nbsp&nbsp
                    <a href="www.youtube.com"><img src="./img/youtube-logo.png" /></a>&nbsp&nbsp
                    <a href="www.twitter.com"><img src="./img/twiiter-icon.png" /></a>&nbsp&nbsp
                    <a href="www.googleplus.com"><img src="./img/g+.png" /></a>&nbsp&nbsp
                    <a href="www.linkedin.com"><img src="./img/linkedin-icon.png" /></a>
                </div>
            </div>
        </div>
        
    </body>



</html>