<!-- For Singup Page for users -->
<?php
	include_once("connection.php");
	session_start();
	
	if(isset($_POST['submit']))  {
		 
		$name = $_POST['name'];
		// $image = $_POST['myimage'];
		$username = $_POST['username'];
		$email = $_POST['email'];
		$password = $_POST['password'];	
		 
		/* First we will check username/pass/email valid */
		$selectQ = "select * from usertable";
		$userQuery = mysqli_query($link, $selectQ);
			
		$match;
		while($row = mysqli_fetch_assoc($userQuery)){
			$match = strcmp($username, $row['username']);
			if($match == 0){
				//username is already taken;
				echo '<script> alert("username is already taken!"); </script>';
			}
		} 
		 
		 
		 /*image processing*/
		$imageName = mysqli_real_escape_string($link, $_FILES['image']['name']);
		$imageData = mysqli_real_escape_string($link, file_get_contents($_FILES['image']['tmp_name']));
		$imageType = mysqli_real_escape_string($link, $_FILES['image']['type']);
		
		 
	 
		$q = "insert into usertable (image, name, email, username, password) value ('$imageData','$name', '$email', '$username', '$password')";
		
		//$rs = mysqli_query($link, $q);
		$rs = mysqli_query($link, $q);
	 
		if($rs){
			echo"record has be saved";
			//sign the user and redirect to main page
			
			$_SESSION['username'] = $username;
			$_SESSION['admin'] = 0;			//as this page is only responsible for user signup/
			
			header('Location: main.php');
		
		}
		else{
			echo"Fail to save";
		    die(mysqli_error($link));
		}  
	 }
	 else {
		 
	 }
	
	function checkValid($username, $password, $email){
		
		
	}
	
	
?>


<html>
    <head>
        <title>Signup</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery-3.1.1.min.js"></script>
        <!-- Bootstrap js link -->
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body style="background-color:black;">

        <div class="navbar navbar-dark">
            <div class="container">
            <div class="navbar-header ">
                <img src="./img/GIP_logo.jpg" width="60px" height="60px" />
            </div>
            <ul class="nav navbar-nav navbar-left">
            <li><a href="main.php">Home</a></li>
            <li class="dropdown"><a  href="#" class="dropdown-toggle" data-toggle="dropdown">About<i class="caret"></i></a>
            <ul class="dropdown-menu">
            <li><a href="#">video</a></li>
            <li><a href="#">gallery</a></li>
            <li><a href="#">Music</a></li>
            </ul>
            </li>
            <li><a href="#">Contact Us</a></li>
            
            </ul>
            <ul class="nav navbar-nav navbar-right">
            <li><a href="signin.php" class="btn btn-info" style="margin-top: 5px;">Signin</a></li>
            </ul>
            
            </div>
            
            </div>
        </div>

        <br /><br /><br /><br />

        <div class="container" style="background-color: darkgray; border-radius: 25px;">
            <form action="" method="POST" enctype="multipart/form-data">
                <br />
                <label>Enter profile Image:</label>
                <input  type="file" id="myimage" name="image" accept="image/*" class="form-control" type="file" style="background-color: lightgray;" required/>
                <label>Name:</label>
                <input class="form-control" type="text" placeholder="Enter your name" name="name" style="background-color: lightgray;"/>
                <label>Email Address:</label>
                <input class="form-control" type="email" placeholder="Enter your email" name="email" style="background-color: lightgray;"/>
                <label>Username:</label>
                <input class="form-control" type="text" placeholder="Enter Username" name="username" style="background-color: lightgray;"/>
                <label>Password:</label>
                <input class="form-control" type="password" placeholder="Enter your password" name="password" style="background-color: lightgray;" />
                <label>Confirm Password:</label>
                <input class="form-control" type="password" placeholder="Retype Password" name="pass" style="background-color: lightgray;"/>
                <br />
                <button type="submit" value="submit" name="submit" class="btn btn-success" style="float: left;">Register</button>
                <br /><br />
            </form>
        </div>
        <br /><br /><br /><br /><br />
        <div class="container" >
            <div class="col-md-12">
                <div class="col-md-2">
                    <img src="./img/GIP_logo.jpg" width="100px" height="100px" style="margin-top: 25px;" />
                </div>
                <br /><br />
                <div class="col-md-6">
                    <a href="#">About</a> &nbsp&nbsp&nbsp&nbsp <a href="#">Blog</a>
                    &nbsp&nbsp&nbsp&nbsp <a href="#">News</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Help Center</a>
                    &nbsp&nbsp&nbsp&nbsp <a href="#">Sitemap</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Terms of Services & honor code</a>
                    &nbsp&nbsp&nbsp&nbsp <a href="#">Privacy Policy</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Acceptibility policy</a>
                    <br /><br />
                    <p>@Copyrights <i class="fa fa-copyright" aria-hidden="true"></i> 2020 Game Info Portal inc. All rightes reserved except where noted</p>
                </div>
                <br />
                <div class="col-md-4">
                    <a href="www.facebook.com"><img src="./img/fb_icon.png" /></a>&nbsp&nbsp
                    <a href="www.youtube.com"><img src="./img/youtube-logo.png" /></a>&nbsp&nbsp
                    <a href="www.twitter.com"><img src="./img/twiiter-icon.png" /></a>&nbsp&nbsp
                    <a href="www.googleplus.com"><img src="./img/g+.png" /></a>&nbsp&nbsp
                    <a href="www.linkedin.com"><img src="./img/linkedin-icon.png" /></a>
                </div>
            </div>
        </div>
        
    </body>



</html>