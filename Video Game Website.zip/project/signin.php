<!-- For Singin Page -->
<?php
	include_once("connection.php");
	session_start();
?>

<?php
if(isset($_POST['submit'])){
		//first chk wheather the user exist in database or not
		//if yes then save the it in session variable
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		
		
		/*	Query for finding user in admintable	*/
		$q = "select * from admintable";
		$query = mysqli_query($link, $q);
											 //admin Status	
		findUser($query, $username, $password, 1);
		
		/*	Query for finding user in usertable	*/
		$q = "select * from usertable";
		$query = mysqli_query($link, $q);
		
		findUser($query, $username, $password, 0);
		
	}
	else{
		//nothing
	}

?>

<?php
	function findUser($query, $username, $password, $admin_status){
		$flag = 0;
		while($row = mysqli_fetch_assoc($query)){
			$username_chk = strcmp($username, $row['username']);
			if($username_chk == 0){
				//found!
				$flag = 1;
				echo "user found\n";
				if($password == $row['password']){
					echo "YOu are LOged IN\n";
					$_SESSION['username'] = $username;
					$_SESSION['admin'] = $admin_status;
					//redirect the user to main page
					header('Location: main.php');
					return;
				}else{
					echo "Password did not match\n";
				}
				
				break;
			}
		}
		
		if($flag == 0){
			echo "user not found!";
		}
	}
?>


<html>
    <head>
        <title>Signin</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <script src="js/jquery-3.1.1.min.js"></script>
        <!-- Bootstrap js link -->
        <script src="js/bootstrap.min.js"></script>
    </head>
    <body style="background-color:black;">

        <div class="navbar navbar-dark">
            <div class="container">
            <div class="navbar-header ">
                <img src="./img/GIP_logo.jpg" width="60px" height="60px" />
            </div>
            <ul class="nav navbar-nav navbar-left">
            <li><a href="main.php">Home</a></li>
            <li class="dropdown"><a  href="#" class="dropdown-toggle" data-toggle="dropdown">About<i class="caret"></i></a>
            <ul class="dropdown-menu">
            <li><a href="#">video</a></li>
            <li><a href="#">gallery</a></li>
            <li><a href="#">Music</a></li>
            </ul>
            </li>
            <li><a href="contactUsPage.php">Contact Us</a></li>
            
            </ul>
            <ul class="nav navbar-nav navbar-right">
            <li><a  class="btn btn-info" style="margin-top: 5px;">Signin</a></li>
            </ul>
            
            </div>
            
            </div>
        </div>

        <br /><br /><br /><br />

        <div class="container" style="background-color: darkgray; border-radius: 25px;">
            <form action="" method="POST" enctype="multipart/form-data">
                <br />
                <label>User Name:</label>
                <input class="form-control" type="text" placeholder="Enter your name" name="username" style="background-color: lightgray;"/>
                <label>Password:</label>
                <input class="form-control" type="password" placeholder="Enter your password" name="password" style="background-color: lightgray;" />
                <br />
                <button type="submit" value="submit" name="submit" class="btn btn-primary" style="display:block; margin-left: auto; margin-right: auto;">Signin</button>
                
            </form>
            
            <a href="signup.php"> <button class="btn btn-danger" style="display:block; margin-left: auto; margin-right: auto;">Signup </button> </a>
            <br /><br />
        </div>
        <br /><br /><br /><br /><br />
        <div class="container" >
            <div class="col-md-12">
                <div class="col-md-2">
                    <img src="./img/GIP_logo.jpg" width="100px" height="100px" style="margin-top: 25px;" />
                </div>
                <br /><br />
                <div class="col-md-6">
                    <a href="#">About</a> &nbsp&nbsp&nbsp&nbsp <a href="#">Blog</a>
                    &nbsp&nbsp&nbsp&nbsp <a href="#">News</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Help Center</a>
                    &nbsp&nbsp&nbsp&nbsp <a href="#">Sitemap</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Terms of Services & honor code</a>
                    &nbsp&nbsp&nbsp&nbsp <a href="#">Privacy Policy</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Acceptibility policy</a>
                    <br /><br />
                    <p>@Copyrights <i class="fa fa-copyright" aria-hidden="true"></i> 2020 Game Info Portal inc. All rightes reserved except where noted</p>
                </div>
                <br />
                <div class="col-md-4">
                    <a href="www.facebook.com"><img src="./img/fb_icon.png" /></a>&nbsp&nbsp
                    <a href="www.youtube.com"><img src="./img/youtube-logo.png" /></a>&nbsp&nbsp
                    <a href="www.twitter.com"><img src="./img/twiiter-icon.png" /></a>&nbsp&nbsp
                    <a href="www.googleplus.com"><img src="./img/g+.png" /></a>&nbsp&nbsp
                    <a href="www.linkedin.com"><img src="./img/linkedin-icon.png" /></a>
                </div>
            </div>
        </div>
        
    </body>

</html>


