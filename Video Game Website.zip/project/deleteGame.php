<!-- updating game -->
<?php
	 echo "UPDAING THE GAME!\n";
	 include_once("connection.php");
	 
	 $selected_ID; 
	 
	 if(isset($_GET['id'])){
		 $selected_ID = $_GET['id'];
		 $q = "DELETE from games WHERE id=".$selected_ID;
		 $query = mysqli_query($link, $q);
		 //$row = mysqli_fetch_assoc($query);
		 echo '<script> alert("Game Deleted!"); </script>';
		 header('Location: edit_games.php');
		 
	 }else{
		 echo "NO  GET";
	 }

?>	

<html>
<head>
<meta charset="utf-8">

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>

</html>

