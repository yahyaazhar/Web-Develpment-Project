<?php
	include_once("connection.php");
	
	$row = "select * from games";

	$ri = mysqli_query($link, $row); 
	
	$row = array();
	while($x = mysqli_fetch_assoc($ri)){
		array_push($row, $x);
	}
?>
<html>
<head>

<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>

<body class="container">
</br></br>
<table class="table table-hover">
	<tr>
		<th><center> Images </center></th>
		
	</tr>


	<tr>
	<td>
	<?php 
		
		$image = imagecreatefromstring($row['image']);
		$image = imagescale($image, 150, 150);
		//$image = imagecreatetruecolor(100, 100);
		//imageresolution($image, 200);
		
		ob_start();
		imagejpeg($image);
		$content = ob_get_contents();
		ob_end_clean();
		echo '<img src="data:image/jpeg;base64,'.base64_encode($content).'"/>'; ?>
	<td> <?php echo $row['name']; ?> </td>
	<td> <?php echo $row['genre']; ?> </td>
	<td> <?php echo $row['platform']; ?> </td>
	
	</tr>
	
	
	
</table>
	
</body>

</html>

