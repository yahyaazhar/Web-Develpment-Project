<!-- For Singin Page -->
<?php
	include_once("connection.php");
	session_start();
	session_destroy();
	echo "You have signed out\n";
	header('Location: main.php');
?>

