<?php
    include_once("connection.php");
	session_start();
	
	//for entertaining search query
	if(isset($_POST['submit'])){
		$search = $_POST['search'];
		
		//getting id of the game
		$gameQ = 'select * from games';
		$query = mysqli_query($link, $gameQ);
		
		$flag = 0;	// a chk for game existance
		while($row = mysqli_fetch_assoc($query)){
			$result = strcmp($search, $row['name']);
			if($result == 0){
				$flag = 1;
				
				$id = $row['id'];
				
				$q = 'select * from games where id='.$id;
				$query = mysqli_query($link, $q);
				
				break;
				
			}
		}
		
		if($flag == 0){
			echo "NO RESULT";
		}
		
		
	}
	else{
		$q = "select * from games";
		$query = mysqli_query($link, $q);
	}
	

?>


<html>
<head>
<title>Web Project</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/my_css.css">
        <script src="js/jquery-3.1.1.min.js"></script>
        <!-- Bootstrap js link -->
        <script src="js/bootstrap.min.js"></script>

</head>

<body class="container" style="background-color: black;">
<div class="navbar navbar-dark">
            <div class="container">
            <div class="navbar-header ">
                <img src="./img/GIP_logo.jpg" width="60px" height="60px" />
            </div>
            <ul class="nav navbar-nav navbar-left">
            <li><a href="main.php">Home</a></li>
            <li class="dropdown"><a  href="#" class="dropdown-toggle" data-toggle="dropdown">About<i class="caret"></i></a>
            <ul class="dropdown-menu">
            <li><a href="#">video</a></li>
            <li><a href="#">gallery</a></li>
            <li><a href="#">Music</a></li>
            </ul>
            </li>
            <li><a href="contactUsPage.php">Contact Us</a></li>
           
		    <!-- For Searching -->
		
		<form action="view_all.php" method="POST" enctype="multipart/form-data">
            <li>
			<div class="search-container" style="margin-top: 15px; margin-left: 10px;">
			<input type="text" placeholder="Search" id="search" name="search" style="width: 200%;" />
			</div>
			</li>
			<li><button type="submit" value="submit" name="submit" class="btn btn-primary" style="margin-top: 14px; margin-left: 180px;">
			<span class="glyphicon glyphicon-search">
			</span></button>
			</li>
		</form>
		
		<!-- -->
		
            <!--- Changing Sign In Depend Log in Status -->
            </ul>
			<?php 
			if(!isset($_SESSION['username'])) { ?>
				<ul class="nav navbar-nav navbar-right">
				<li><a href="signinPage.php" class="btn btn-info" style="margin-top: 5px;">Signin</a></li>
				</ul>
            <?php } 
			
			else if(isset($_SESSION['username']) && $_SESSION['admin'] == 1){ ?>
				<ul class="nav navbar-nav navbar-right">
				<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle btn-primary" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					Dropdown
				</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
					<a class="dropdown-item" href="newentry.php">Add Games</a>
					<a class="dropdown-item" href="edit_games.php">Edit Games</a>
					<a class="dropdown-item" href="signoutPage.php">Signout</a>
					
				</div>
				</li>
				</ul>
			<?php } 
			else if(isset($_SESSION['username']) && $_SESSION['admin'] == 0){ ?>
				<ul class="nav navbar-nav navbar-right">
				<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle btn-primary" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					ForUser
				</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
					<a class="dropdown-item" href="newentry.php">Upload Game</a>
					<a class="dropdown-item" href="userProfile.php">My Profile</a>
					<a class="dropdown-item" href="signoutPage.php">Signout</a>
					
				</div>
				</li>
				</ul>
			<?php } ?>
				
            
			<!------------------------------------------->
			</div>
            
            </div>
        </div>
        <br />  

        
      <table class="table">
        <thead>
            <tr>
                <th style="color: white;"><b>Name</b></th>
                <th style="color: white;"><b>Image</b></th>
                <th style="color: white;"><b>Genre</b></th>
                <th style="color: white;"><b>Platform</b></th>
            </tr>
        </thead>
        <?php while($row = mysqli_fetch_assoc($query)) 
		  {
		?>		  
		<form class="form-group" method="get" action="updateGamePage.php" enctype="multipart/form-data" >
		<tr>
         <td>
			<a href="gameinfo.php?id=<?php echo $row['id'] ?>"><?php setImage($row['image']); ?></a>
		 </td>
         <td><?php echo "<span><a style='color:lightblue' href='gameinfo.php?id=".$row['id']."'> ".$row['name']." </a></span>"; 
			?></td>
         <td style="color:white"><?php echo $row['genre'] ?></td>
         <td style="color:white"><?php echo $row['platform'] ?></td>
		 <td><a href="updateGamePage.php?id=<?php echo $row['id'] ?>"><input type="button" value="Edit" class="btn btn-warning">  </td>
		 <td><a href="deleteGame.php?id=<?php echo $row['id'] ?>"><input type="button" value="Delete" class="btn btn-danger">  </td>
		 
       </tr>
	</form>
	<?php }
	?>
    </table>

    <nav style="text-align:center;">
    <ul class="pagination">
            <li class="disabled">
                <a href="#" aria-label="previous">
                    <span aria-hidden="true">&laquo;</span>
                    <span class="sr-only ">previous</span>
                </a>
            </li>
            <li class="active"><a href="#">1</a></li>
            <li><a href="viewall1.php">2</a></li>

            <li>
                <a href="viewall1.php" aria-label="next">
                    <span aria-hidden="true">&raquo;</span>
                    <span class="sr-only">next</span>
                </a>
            </li>

    </ul>
    </nav>

    <div class="container">
                <div class="col-md-12">
                    <div class="col-md-2">
                        <img src="./img/GIP_logo.jpg" width="100px" height="100px" style="margin-top: 25px;" />
                    </div>
                    <br /><br />
                    <div class="col-md-6">
                        <a href="#">About</a> &nbsp&nbsp&nbsp&nbsp <a href="#">Blog</a>
                        &nbsp&nbsp&nbsp&nbsp <a href="#">News</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Help Center</a>
                        &nbsp&nbsp&nbsp&nbsp <a href="#">Sitemap</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Terms of Services & honor code</a>
                        &nbsp&nbsp&nbsp&nbsp <a href="#">Privacy Policy</a>&nbsp&nbsp&nbsp&nbsp <a href="#">Acceptibility policy</a>
                        <br /><br />
                        <p>@Copyrights <i class="fa fa-copyright" aria-hidden="true"></i> 2020 Game Info Portal inc. All rightes reserved except where noted</p>
                    </div>
                    <br />
                    <div class="col-md-4">
                        <a href="www.facebook.com"><img src="./img/fb_icon.png" /></a>&nbsp&nbsp
                        <a href="www.youtube.com"><img src="./img/youtube-logo.png" /></a>&nbsp&nbsp
                        <a href="www.twitter.com"><img src="./img/twiiter-icon.png" /></a>&nbsp&nbsp
                        <a href="www.googleplus.com"><img src="./img/g+.png" /></a>&nbsp&nbsp
                        <a href="www.linkedin.com"><img src="./img/linkedin-icon.png" /></a>
                    </div>
                </div>
            </div>


</body>


<footer>
</footer>
</html>

<?php
	function setImage($img){
		$image = imagecreatefromstring($img);
		$image = imagescale($image, 130, 130);
		
		ob_start();
		imagejpeg($image);
		$content = ob_get_contents();
		ob_end_clean();
		echo '<img src="data:image/jpeg;base64,'.base64_encode($content).'"/>';
	}
?>